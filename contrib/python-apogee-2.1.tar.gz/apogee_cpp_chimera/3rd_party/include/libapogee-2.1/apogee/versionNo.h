#if !defined(VERSION_NUM_H___)
#define VERSION_NUM_H___

// for windows
#define FILEVER        2,1,268,1931
#define PRODUCTVER     2,1,268,1931
#define STRFILEVER     "2, 1, 268, 1931\0"
#define STRPRODUCTVER  "2, 1, 268, 1931\0"

// for linux
#define APOGEE_MAJOR_VERSION 2
#define APOGEE_MINOR_VERSION 1
#define APOGEE_PATCH_VERSION 1931

#endif
