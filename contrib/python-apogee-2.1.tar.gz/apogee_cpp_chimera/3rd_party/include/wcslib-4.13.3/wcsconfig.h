/* wcsconfig.h.  Generated from wcsconfig.h.in by configure.  */
/*============================================================================
*
*   wcsconfig.h is generated from wcsconfig.h.in by 'configure'.  It contains
*   C preprocessor macro definitions for compiling WCSLIB 4.13
*
*   Author: Mark Calabretta, Australia Telescope National Facility
*   http://www.atnf.csiro.au/~mcalabre/index.html
*   $Id: wcsconfig.h.in,v 4.13.1.1 2012/03/14 07:40:38 cal103 Exp cal103 $
*===========================================================================*/

/* WCSLIB library version number. */
#define WCSLIB_VERSION 4.13.3

/* Define to 1 if sincos() is available. */
#define HAVE_SINCOS 1

/* 64-bit integer data type. */
#define WCSLIB_INT64 long long int
