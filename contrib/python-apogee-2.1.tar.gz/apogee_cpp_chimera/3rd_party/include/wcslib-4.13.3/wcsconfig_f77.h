/* wcsconfig_f77.h.  Generated from wcsconfig_f77.h.in by configure.  */
/*============================================================================
*
*   wcsconfig_f77.h is generated from wcsconfig_f77.h.in by 'configure'.  It
*   contains C preprocessor definitions for building the WCSLIB 4.13 Fortran
*   wrappers.
*
*   Author: Mark Calabretta, Australia Telescope National Facility
*   http://www.atnf.csiro.au/~mcalabre/index.html
*   $Id: wcsconfig_f77.h.in,v 4.13.1.1 2012/03/14 07:40:38 cal103 Exp cal103 $
*===========================================================================*/

/* Integer array type large enough to hold an address.  Set here to int[2] for
 * 64-bit addresses, but could be defined as int* on 32-bit machines. */
typedef int iptr[2];

/* Macro for mangling Fortran subroutine names that do not contain
 * underscores.  Typically a name like "WCSINI" (case-insensitive) will become
 * something like "wcsini_" (case-sensitive).  The Fortran wrappers, which are
 * written in C, are preprocessed into names that match the latter.  The macro
 * takes two arguments which specify the name in lower and upper case. */
#define F77_FUNC(name,NAME) name ## _
