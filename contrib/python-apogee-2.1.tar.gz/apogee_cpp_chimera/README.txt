# to compile
1) mkdir build
2) cd build
3) cmake ..
4) make
